import pygame
import math
import random

from NuclearData import KNOWN_NEUTRONS, KNOWN_ANIONS, ELEMENT_SYMBOL, CATEGORY_COLOR, ELEMENT_DATA, ISOTOPE_DATA

def allowed_electrons(Z):
    allowed = list(range(0, Z + 1))  # 0..Z (positive ions + neutral)

    # Add negative ions based on KNOWN_ANIONS
    for neg in KNOWN_ANIONS.get(Z, []):
        allowed.append(Z + neg)

    return allowed


def snap_n(Z, n):
    allowed = KNOWN_NEUTRONS.get(Z, [])
    return min(allowed, key=lambda x: abs(x - n))


def snap_e(Z, e):
    allowed = allowed_electrons(Z)
    return min(allowed, key=lambda x: abs(x - e))


TINY = {
    "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴",
    "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹",
    "+": "⁺", "-": "⁻"
}

def tiny(s):
    return "".join(TINY.get(ch, ch) for ch in s)

def charge_to_tiny(q):
    if q == 0:
        return ""
    sign = "+" if q > 0 else "-"
    mag = abs(q)
    raw = sign if mag == 1 else f"{mag}{sign}"
    return tiny(raw)
    
    
SUPERSCRIPTS = {
    "-": "⁻", "–": "⁻", "+": "⁺",
    "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴",
    "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹",
}

def to_superscript(num: int) -> str:
    s = str(num)
    out = []
    for ch in s:
        if ch in SUPERSCRIPTS:
            out.append(SUPERSCRIPTS[ch])
        else:
            out.append(ch)
    return "".join(out)

def format_charge_superscript(charge: int) -> str:
    if charge == 0:
        return ""
    sign = "+" if charge > 0 else "−"
    mag = abs(charge)
    if mag == 1:
        return SUPERSCRIPTS[sign]
    return to_superscript(mag) + SUPERSCRIPTS[sign]


pygame.init()

# Window
WIDTH, HEIGHT = 900, 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Atom Viewer MVP")

# Atom surface (virtual canvas)
ATOM_SIZE = 512
atom_surface = pygame.Surface((ATOM_SIZE, ATOM_SIZE))

UI_FONT = pygame.font.Font("DejaVuSans.ttf", 30)

# Colors
BG = (40, 40, 40)
SHELL_COLOR = (120, 120, 120)
OUTLINE = (0, 0, 0)

PROTON_BASE = (200, 40, 40)
PROTON_HL = (255, 120, 120)

NEUTRON_BASE = (40, 80, 200)
NEUTRON_HL = (120, 160, 255)

ELECTRON_BASE = (220, 200, 40)
ELECTRON_HL = (255, 255, 160)



class Slider:
    def __init__(self, x, y, w, h, min_val, max_val, value, label, integer=True):
        self.rect = pygame.Rect(x, y, w, h)
        self.min_val = min_val
        self.max_val = max_val
        self.value = value
        self.label = label
        self.integer = integer
        self.dragging = False

        # knob size independent of slider thickness
        self.knob_radius = max(10, min(w, h) // 1.75)

    def handle_event(self, event):
        is_vertical = self.rect.height > self.rect.width

        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.dragging = True

        elif event.type == pygame.MOUSEBUTTONUP:
            self.dragging = False

        elif event.type == pygame.MOUSEMOTION and self.dragging:
            if not is_vertical:
                # horizontal drag
                x = max(self.rect.left, min(event.pos[0], self.rect.right))
                t = (x - self.rect.left) / self.rect.width
            else:
                # vertical drag (0 at TOP)
                y = max(self.rect.top, min(event.pos[1], self.rect.bottom))
                t = (y - self.rect.top) / self.rect.height  # 0 at top, 1 at bottom

            val = self.min_val + t * (self.max_val - self.min_val)
            self.value = int(round(val)) if self.integer else val

    def draw(self, surface, font):
        is_vertical = self.rect.height > self.rect.width
    
        # draw bar
        pygame.draw.rect(surface, (80, 80, 80), self.rect, border_radius=6)
    
        # compute knob position
        t = (self.value - self.min_val) / (self.max_val - self.min_val or 1)
    
        if not is_vertical:
            # horizontal knob
            hx = int(self.rect.left + t * self.rect.width)
            hy = self.rect.centery
        else:
            # vertical knob (0 at top)
            hx = self.rect.centerx
            hy = int(self.rect.top + t * self.rect.height)
    
        if getattr(self, "show_knob", True):
            pygame.draw.circle(surface, (220, 220, 220), (hx, hy), self.knob_radius)
    
        # TEXT FORMATTING
        if not is_vertical:
            # PORTRAIT MODE
            text = f"{self.label} = {self.value}"
            img = font.render(text, True, (230, 230, 230))
            surface.blit(img, (self.rect.centerx - img.get_width() // 2,
                               self.rect.top - img.get_height() - 4))
    
        else:
            # LANDSCAPE MODE
            # Two-line format:
            # Name
            # Value
            name_img = font.render(self.label, True, (230, 230, 230))
            val_img  = font.render(str(self.value), True, (230, 230, 230))
    
            # place text BELOW the slider
            text_x = self.rect.centerx - name_img.get_width() // 2
            text_y = self.rect.bottom + 64
    
            surface.blit(name_img, (text_x, text_y))
            surface.blit(val_img, (self.rect.centerx - val_img.get_width() // 2, text_y + name_img.get_height() + 2))
    
def update_slider_visibility(slider):
    # Hide knob if no range
    slider.show_knob = not (slider.min_val == slider.max_val)

#--------------------------------
# INFO BOX
#--------------------------------

def get_category_color(Z):
    if Z == 0:
        return (50, 50, 50)

    # Noble gases
    if Z in (2, 10, 18, 36, 54, 86, 118):
        return CATEGORY_COLOR["noble"]

    # Nonmetals
    if Z in (1, 6, 7, 8, 15, 16, 34):
        return CATEGORY_COLOR["nonmetal"]

    # Halogens
    if Z in (9, 17, 35, 53, 85, 117):
        return CATEGORY_COLOR["halogen"]

    # Alkali metals
    if Z in (3, 11, 19, 37, 55, 87):
        return CATEGORY_COLOR["alkali"]

    # Alkaline earth metals
    if Z in (4, 12, 20, 38, 56, 88):
        return CATEGORY_COLOR["alkaline"]

    # Metalloids
    if Z in (5, 14, 32, 33, 51, 52, 84):
        return CATEGORY_COLOR["metalloid"]

    # Lanthanides
    if 57 <= Z <= 71:
        return CATEGORY_COLOR["lanth"]

    # Actinides
    if 89 <= Z <= 103:
        return CATEGORY_COLOR["actin"]

    # Transition metals
    if (21 <= Z <= 30) or (39 <= Z <= 48) or (72 <= Z <= 80) or (104 <= Z <= 112):
        return CATEGORY_COLOR["transition"]

    # Everything else = post-transition metals → use "metal"
    return CATEGORY_COLOR["metal"]

def draw_element_box(surface, Z, symbol, portrait):
    sw, sh = surface.get_size()

    # perfect square box
    box_size = int(min(sw, sh) * 0.22)
    box_w = box_size
    box_h = box_size

    margin = int(sw * 0.03)

    # position
    if portrait:
        x = margin+25
        y = sh - box_h - margin- 125
    else:
        x = sw - box_w - margin -100
        y = (sh - box_h) // 2 + 32

    # fonts
    font_Z = pygame.font.Font("DejaVuSans.ttf", int(box_h * 0.18))
    font_symbol = pygame.font.Font("DejaVuSans.ttf", int(box_h * 0.55))

    # background color
    color = get_category_color(Z)
    pygame.draw.rect(surface, color, (x, y, box_w, box_h), border_radius=12)
    pygame.draw.rect(surface, (255,255,255), (x, y, box_w, box_h), 3, border_radius=12)

    # Z (top-left)
    z_img = font_Z.render(str(Z), True, (255,255,255))
    surface.blit(z_img, (x + int(box_w * 0.06), y + int(box_h * 0.04)))

    # Symbol (center)
    sym_img = font_symbol.render(symbol, True, (255,255,255))
    sx = x + (box_w - sym_img.get_width()) // 2
    sy = y + 10 + (box_h - sym_img.get_height()) // 2
    surface.blit(sym_img, (sx, sy))


def is_isotope_stable(Z: int, A: int) -> bool | None:
    key = (Z, A)
    data = ISOTOPE_DATA.get(key)
    if data is None:
        return None  # unknown
    return bool(data.get("stable", False))

def is_element_radioactive(Z: int) -> bool:
    elem = ELEMENT_DATA.get(Z, {})
    has_stable = elem.get("has_stable_isotopes", True)
    if not has_stable:
        return True
    if Z > 82:
        return True
    return False

def is_nuclide_radioactive(Z: int, A: int) -> bool | None:
    stable = is_isotope_stable(Z, A)
    if stable is None:
        return None
    return not stable
    
    
def compute_current_atom_info(protons: int, neutrons: int, electrons: int):
    Z = protons
    A = protons + neutrons
    charge = protons - electrons

    elem = ELEMENT_DATA.get(Z, {})
    symbol = elem.get("symbol", "?")
    name = elem.get("name", "Unknown")

    # scientific name: A^sup Symbol charge^sup
    sci_A = to_superscript(A)
    sci_charge = format_charge_superscript(charge)
    scientific = f"{sci_A}{symbol}{sci_charge}"

    # ion type
    if charge > 0:
        ion_type = "Cation"
    elif charge < 0:
        ion_type = "Anion"
    else:
        ion_type = "Neutral"

    neutron_excess = neutrons - protons
    nz_ratio = (neutrons / protons) if protons > 0 else 0.0

    stable_flag = is_nuclide_radioactive(Z, A)
    if stable_flag is None:
        stability = "Unknown"
    elif stable_flag:
        stability = "Radioactive"
    else:
        stability = "Stable"

    # radioactivity symbol
    show_radio = (stable_flag is True) or is_element_radioactive(Z)
    radio_symbol = "☢" if show_radio else ""

    # electron configuration: you already have distribute_electrons()
    shells = distribute_electrons(electrons)
    shell_str = ", ".join(str(s) for s in shells) if shells else "0"

    category = elem.get("category", "Unknown")
    period = elem.get("period", "?")
    group = elem.get("group", "?")

    return {
        "name": name,              # you can override with your fun name
        "scientific": scientific,
        "p": protons,
        "n": neutrons,
        "e": electrons,
        "A": A,
        "charge": charge,
        "ion_type": ion_type,
        "neutron_excess": neutron_excess,
        "nz_ratio": nz_ratio,
        "stability": stability,
        "radio": radio_symbol,
        "shells": shell_str,
        "category": category,
        "period": period,
        "group": group,
    }


def compute_reference_atom_info(protons: int):
    Z = protons
    elem = ELEMENT_DATA.get(Z, {})
    symbol = elem.get("symbol", "?")
    name = elem.get("name", "Unknown")

    A_ref = elem.get("most_common_A", Z)
    n_ref = A_ref - Z
    e_ref = Z

    sci_A = to_superscript(A_ref)
    scientific = f"{sci_A}{symbol}"

    category = elem.get("category", "Unknown")
    period = elem.get("period", "?")
    group = elem.get("group", "?")
    block = elem.get("block", "?")
    electroneg = elem.get("electronegativity", None)
    radius = elem.get("radius", None)
    state = elem.get("state", "Unknown")

    radioactive = is_element_radioactive(Z)
    radio_symbol = "☢" if radioactive else ""

    return {
        "name": name,
        "scientific": scientific,
        "p": Z,
        "n": n_ref,
        "e": e_ref,
        "A": A_ref,
        "category": category,
        "period": period,
        "group": group,
        "block": block,
        "electronegativity": electroneg,
        "radius": radius,
        "state": state,
        "radio": radio_symbol,
    }
    
        
            
def render_atom_info_panel(surface, protons, neutrons, electrons, x, y):
    current = compute_current_atom_info(protons, neutrons, electrons)
    reference = compute_reference_atom_info(protons)

    font = UI_FONT  # whatever font you use

    lines_current = [
        f"CURRENT",
        f"Name: {current['name']}",
        f"Sci: {current['scientific']} {current['radio']}",
        f"p: {current['p']}  n: {current['n']}  e: {current['e']}",
        f"A: {current['A']}",
        f"Charge: {current['charge']} ({current['ion_type']})",
        f"Neutron excess: {current['neutron_excess']}",
        f"N/Z: {current['nz_ratio']:.2f}",
        f"Stability: {current['stability']}",
        f"Shells: {current['shells']}",
        f"Category: {current['category']}",
        f"Period: {current['period']}  Group: {current['group']}",
    ]

    lines_ref = [
        f"REFERENCE",
        f"Name: {reference['name']}",
        f"Sci: {reference['scientific']} {reference['radio']}",
        f"p: {reference['p']}  n: {reference['n']}  e: {reference['e']}",
        f"A: {reference['A']}",
        f"Category: {reference['category']}",
        f"Period: {reference['period']}  Group: {reference['group']}",
        f"Block: {reference['block']}",
        f"State: {reference['state']}",
    ]

    yy = y
    for line in lines_current:
        txt = font.render(line, True, (255, 255, 255))
        surface.blit(txt, (x, yy))
        yy += txt.get_height() + 2

    yy += 8  # gap

    for line in lines_ref:
        txt = font.render(line, True, (200, 200, 200))
        surface.blit(txt, (x, yy))
        yy += txt.get_height() + 2                    

def render_current_info_panel(surface, protons, neutrons, electrons, x, y):
    current = compute_current_atom_info(protons, neutrons, electrons)
    font = UI_FONT

    lines = [
        "CURRENT",
        f"Name: {current['name']}",
        f"Sci: {current['scientific']} {current['radio']}",
        f"p: {current['p']}  n: {current['n']}  e: {current['e']}",
        f"A: {current['A']}",
        f"Charge: {current['charge']} ({current['ion_type']})",
        f"Neutron excess: {current['neutron_excess']}",
        f"N/Z: {current['nz_ratio']:.2f}",
        f"Stability: {current['stability']}",
        f"Shells: {current['shells']}",
        f"Category: {current['category']}",
    ]

    yy = y
    for line in lines:
        txt = font.render(line, True, (255, 255, 255))
        surface.blit(txt, (x, yy))
        yy += txt.get_height() + 2
        
def render_reference_info_panel(surface, protons, x, y):
    reference = compute_reference_atom_info(protons)
    font = UI_FONT

    lines = [
        "REFERENCE",
        f"Name: {reference['name']}",
        f"Sci: {reference['scientific']} {reference['radio']}",
        f"p: {reference['p']}  n: {reference['n']}  e: {reference['e']}",
        f"A: {reference['A']}",
        f"Category: {reference['category']}",
        f"Period: {reference['period']}  Group: {reference['group']}",
        f"Block: {reference['block']}",
        f"State: {reference['state']}",
    ]

    yy = y
    for line in lines:
        txt = font.render(line, True, (200, 200, 200))
        surface.blit(txt, (x, yy))
        yy += txt.get_height() + 2        
        
# -------------------------------
# DRAW SHADED PARTICLE
# -------------------------------
def draw_particle(surface, x, y, radius, base, highlight):
    pygame.draw.circle(surface, OUTLINE, (x, y), radius + 2)
    pygame.draw.circle(surface, base, (x, y), radius)
    hl_r = max(1, radius // 2)
    pygame.draw.circle(surface, highlight, (x - radius // 3, y - radius // 3), hl_r)


# -------------------------------
# NUCLEUS HELPERS
# -------------------------------
def get_nucleus_radius(total_nucleons):
    return int(20 + (total_nucleons ** (1 / 3)) * 8)


def compute_global_scale(nucleus_radius, shells):
    margin = 20
    max_allowed = ATOM_SIZE // 2 - margin

    if not shells:
        return 1.0

    inner_gap = 100
    logical_outer = nucleus_radius + inner_gap + (len(shells) - 1) * 40

    scale = max_allowed / logical_outer
    return scale  # no min clamp — your choice


# -------------------------------
# NUCLEUS RENDERER (RELAXED PACKING)
# -------------------------------
def draw_nucleus(surface, protons, neutrons, nucleus_radius, scale):
    cx, cy = ATOM_SIZE // 2, ATOM_SIZE // 2
    particle_r = 10
    min_dist = particle_r * 2 - 2

    total = protons + neutrons
    rnd = random.Random(12345)

    # Controls
    INNER_CORE = 0.15   # instead of 0.4
    SOFTNESS = 0.1   # how irregular the boundary is
    CONTAIN  = 0.75   # how strongly the nucleus stays inside radius

    # 1. random points in circle
    positions = []
    for _ in range(total):
        angle = rnd.random() * math.tau
        r = nucleus_radius * math.sqrt(rnd.random())
        x = cx + math.cos(angle) * r
        y = cy + math.sin(angle) * r
        positions.append([x, y])

    # 2. relaxation + containment
    for _ in range(2):  # fewer iterations = looser packing
        # repulsion
        for i in range(total):
            xi, yi = positions[i]
            for j in range(i + 1, total):
                xj, yj = positions[j]
                dx = xj - xi
                dy = yj - yi
                dist2 = dx * dx + dy * dy

                if dist2 < min_dist * min_dist:
                    dist = math.sqrt(dist2) + 0.001
                    overlap = (min_dist - dist) / 2
                    nx = dx / dist
                    ny = dy / dist
                    positions[i][0] -= nx * overlap
                    positions[i][1] -= ny * overlap
                    positions[j][0] += nx * overlap
                    positions[j][1] += ny * overlap

        # containment (keeps nucleus from expanding)
        for p in positions:
            dx = p[0] - cx
            dy = p[1] - cy
            d = math.sqrt(dx * dx + dy * dy)

            # Pull back toward boundary if too far
            if d > nucleus_radius:
                pull = (d - nucleus_radius) * CONTAIN
                p[0] -= dx / d * pull
                p[1] -= dy / d * pull

            # Push outward if too close to center (prevents collapse)
            elif d < nucleus_radius * INNER_CORE:
                push = (nucleus_radius * INNER_CORE - d) * (CONTAIN * 0.5)
                p[0] += dx / (d + 0.001) * push
                p[1] += dy / (d + 0.001) * push

    # 3. Softness jitter (scaled so it doesn't inflate nucleus)
    jitter_amount = SOFTNESS * nucleus_radius * 0.05
    for p in positions:
        p[0] += rnd.uniform(-jitter_amount, jitter_amount)
        p[1] += rnd.uniform(-jitter_amount, jitter_amount)

    # particle colors
    particles = []
    for _ in range(protons):
        particles.append((PROTON_BASE, PROTON_HL))
    for _ in range(neutrons):
        particles.append((NEUTRON_BASE, NEUTRON_HL))

    rnd.shuffle(particles)

    # --- draw all particles onto a temporary surface ---
    temp = pygame.Surface((ATOM_SIZE, ATOM_SIZE), pygame.SRCALPHA)
    
    for (x, y), (base, hl) in zip(positions, particles):
        sx = int(cx + (x - cx) * scale)
        sy = int(cy + (y - cy) * scale)
        nr = max(1, int(particle_r * scale))
        draw_particle(temp, sx, sy, nr, base, hl)
    
    # --- blit the whole nucleus in one go ---
    surface.blit(temp, (0, 0))
        


# -------------------------------
# ELECTRON DISTRIBUTION
# -------------------------------
REAL_SHELL_CAPS = [2, 8, 18, 32, 50, 72, 98]

def distribute_electrons(n):
    shells = []
    for cap in REAL_SHELL_CAPS:
        if n <= 0:
            break
        take = min(cap, n)
        shells.append(take)
        n -= take
    return shells


# -------------------------------
# MAIN RENDER FUNCTION
# -------------------------------
def render_atom(surface, protons, neutrons, electrons):
    surface.fill(BG)

    shells = distribute_electrons(electrons)
    total = protons + neutrons
    nucleus_radius = get_nucleus_radius(total)

    scale = compute_global_scale(nucleus_radius, shells)

    scaled_nucleus = nucleus_radius * scale
    inner_gap = 100
    scaled_base = scaled_nucleus + inner_gap * scale
    scaled_step = 40 * scale

    cx, cy = ATOM_SIZE // 2, ATOM_SIZE // 2

    # nucleus
    draw_nucleus(surface, protons, neutrons, nucleus_radius, scale)

    # -------------------------------
    # SHELLS (batch draw)
    # -------------------------------
    shell_layer = pygame.Surface((ATOM_SIZE, ATOM_SIZE), pygame.SRCALPHA)
    th = max(1, int(2 * scale))
    
    for i in range(len(shells)):
        r = scaled_base + i * scaled_step
        pygame.draw.circle(shell_layer, OUTLINE, (cx, cy), int(r) + th, th)
        pygame.draw.circle(shell_layer, SHELL_COLOR, (cx, cy), int(r), th)
    
    surface.blit(shell_layer, (0, 0))
    
    
    # -------------------------------
    # ELECTRONS (batch draw)
    # -------------------------------
    electron_layer = pygame.Surface((ATOM_SIZE, ATOM_SIZE), pygame.SRCALPHA)
    
    for shell_index, count in enumerate(shells):
        r = scaled_base + shell_index * scaled_step
    
        # deterministic rotation based on full atom state + ring index
        seed = (protons * 1000000) + (neutrons * 1000) + electrons + shell_index
        rng = random.Random(seed)
        angle_offset = rng.random() * math.tau
    
        for i in range(count):
            angle = angle_offset + (math.tau / count) * i
            x = int(cx + math.cos(angle) * r)
            y = int(cy + math.sin(angle) * r)
            er = max(1, int(6 * scale))
            draw_particle(electron_layer, x, y, er, ELECTRON_BASE, ELECTRON_HL)
    
    surface.blit(electron_layer, (0, 0))


# -------------------------------
# MAIN LOOP + RESPONSIVE SLIDERS
# -------------------------------

# initial values
protons = 0
neutrons = 0
electrons = 0

# track orientation
screen_width, screen_height = screen.get_size()
is_landscape = screen_width > screen_height
prev_orientation = is_landscape

SLIDER_FONT = pygame.font.Font("DejaVuSans.ttf", 32)

# -------------------------------
# SLIDER BUILDER
# -------------------------------
def build_sliders(sw, sh, p, n, e):
    if sh > sw:
        # PORTRAIT
        slider_width  = int(sw * 0.90)
        slider_height = int(sh * 0.035)
        font = SLIDER_FONT 

        start_x = (sw - slider_width) // 2
        start_y = int(sh * 0.035)
        gap_y   = int(slider_height * 2.4)

        return [
            Slider(start_x, start_y + 0 * gap_y, slider_width, slider_height, 0, 118, p, "p⁺"),
            Slider(start_x, start_y + 1 * gap_y, slider_width, slider_height, 0, 200, n, "n⁰"),
            Slider(start_x, start_y + 2 * gap_y, slider_width, slider_height, 0, 200, e, "e⁻"),
        ]

    else:
        # LANDSCAPE
        slider_width  = int(sw * 0.05)
        slider_height = int(sh * 0.7)
        font =SLIDER_FONT 

        gap_x = int(slider_width * 1.6)
        start_y = int(sh * 0.12)

        return [
            Slider(int(sw * 0.02) + 0 * gap_x, start_y, slider_width, slider_height, 0, 118, p, "p⁺"),
            Slider(int(sw * 0.02) + 1 * gap_x, start_y, slider_width, slider_height, 0, 200, n, "n⁰"),
            Slider(int(sw * 0.02) + 2 * gap_x, start_y, slider_width, slider_height, 0, 200, e, "e⁻"),
        ]


# initial slider creation
sliders = build_sliders(screen_width, screen_height, protons, neutrons, electrons)


# -------------------------------
# MAIN LOOP
# -------------------------------
running = True
clock = pygame.time.Clock()

while running:
    # --- EVENTS ---
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        for s in sliders:
            s.handle_event(event)

    # --- ORIENTATION CHECK ---
    screen_width, screen_height = screen.get_size()
    is_landscape = screen_width > screen_height

    if is_landscape != prev_orientation:
        sliders = build_sliders(screen_width, screen_height, protons, neutrons, electrons)
        prev_orientation = is_landscape


    # --- READ SLIDER VALUES ---
    p = sliders[0].value
    n = sliders[1].value
    e = sliders[2].value


    # --- REAL PHYSICS LIMITS ---
    allowed_N = KNOWN_NEUTRONS.get(p, [])
    if allowed_N:
        sliders[1].max_val = max(allowed_N)
        sliders[1].min_val = min(allowed_N)
        sliders[1].value = snap_n(p, sliders[1].value)

    allowed_E = allowed_electrons(p)
    sliders[2].min_val = 0
    sliders[2].max_val = max(allowed_E)
    sliders[2].value = snap_e(p, sliders[2].value)

    update_slider_visibility(sliders[1])
    update_slider_visibility(sliders[2])

    if p == 0:
        sliders[0].value = 0
        sliders[1].min_val = sliders[1].max_val = sliders[1].value = 0
        sliders[2].min_val = sliders[2].max_val = sliders[2].value = 0
        update_slider_visibility(sliders[1])
        update_slider_visibility(sliders[2])

    protons = sliders[0].value
    neutrons = sliders[1].value
    electrons = sliders[2].value


    # --- RENDER ATOM ---
    render_atom(atom_surface, protons, neutrons, electrons)

    screen.fill((20, 20, 20))

    target_size = min(screen_width, screen_height)
    scale = target_size / ATOM_SIZE

    scaled_w = int(ATOM_SIZE * scale)
    scaled_h = int(ATOM_SIZE * scale)

    atom_x = (screen_width - scaled_w) // 2
    atom_y = (screen_height - scaled_h) // 2

    scaled_atom = pygame.transform.smoothscale(atom_surface, (scaled_w, scaled_h))
    screen.blit(scaled_atom, (atom_x, atom_y))


    # --- DRAW SLIDERS ---
    for s in sliders:
        font = SLIDER_FONT 
        s.draw(screen, font)


    # --- INFO PANELS + ELEMENT BOX ---
    sw, sh = screen.get_size()
    portrait = sh > sw

    margin = int(sw * 0.03)
    box_size = int(min(sw, sh) * 0.22)

    draw_element_box(screen, protons, ELEMENT_SYMBOL[protons], portrait)

    if portrait:
        elem_x = margin
        elem_y = sh - box_size - margin
    else:
        elem_x = sw - box_size - margin
        elem_y = (sh - box_size) // 2

    if portrait:
        cur_x = elem_x + box_size + margin + 50
        cur_y = elem_y - 200

        ref_x = cur_x + 260 + margin + 75
        ref_y = cur_y

    else:
        cur_x = elem_x - 125
        cur_y = elem_y - 400

        ref_x = elem_x - 125
        ref_y = elem_y + box_size + margin

    render_current_info_panel(screen, protons, neutrons, electrons, cur_x, cur_y)
    render_reference_info_panel(screen, protons, ref_x, ref_y)

    pygame.display.flip()
    clock.tick(30)

pygame.quit()