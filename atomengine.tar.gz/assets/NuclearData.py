KNOWN_NEUTRONS = {
    0: [1, 4, 6],
    1: [0, 1, 2, 3, 4, 5, 6],
    2: [1, 2, 3, 4, 5, 6, 7, 8],
    3: [1, 2, 3, 4, 5, 6, 7, 8, 9],
    4: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    5: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
    6: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16],
    7: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
    8: [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18],
    9: [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22],
    10: [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24],
    11: [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26],
    12: [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28],
    13: [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30],
    14: [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30],
    15: [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31],
    16: [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 32],
    17: [12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35],
    18: [12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35],
    19: [12, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37],
    20: [14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38],
    21: [17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 40],
    22: [16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42],
    23: [19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44],
    24: [18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46],
    25: [19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 47, 48],
    26: [19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50],
    27: [21, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51],
    28: [20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54],
    29: [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54],
    30: [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55],
    31: [28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56],
    32: [27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58],
    33: [30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59],
    34: [29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61],
    35: [32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 66],
    36: [31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66],
    37: [35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69],
    38: [35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70],
    39: [37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72],
    40: [37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74],
    41: [40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76],
    42: [39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77],
    43: [42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79],
    44: [41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81],
    45: [44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83],
    46: [44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85],
    47: [45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85],
    48: [46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86],
    49: [47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88],
    50: [49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90],
    51: [52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91],
    52: [52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93],
    53: [55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94],
    54: [54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96],
    55: [57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97],
    56: [58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98],
    57: [60, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100],
    58: [63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100],
    59: [62, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102],
    60: [65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103],
    61: [67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104],
    62: [67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106],
    63: [67, 68, 69, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106],
    64: [70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108],
    65: [70, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109],
    66: [73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110],
    67: [73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111],
    68: [75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112],
    69: [75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112],
    70: [79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115],
    71: [78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117],
    72: [79, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118],
    73: [82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121],
    74: [83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123],
    75: [84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124],
    76: [85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127],
    77: [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128],
    78: [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130],
    79: [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131],
    80: [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136],
    81: [95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136],
    82: [96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138],
    83: [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141],
    84: [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143],
    85: [106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144],
    86: [107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145],
    87: [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146],
    88: [113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146],
    89: [116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147],
    90: [117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148],
    91: [120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148],
    92: [122, 123, 124, 125, 126, 127, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 161, 162, 163],
    93: [126, 127, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151],
    94: [134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153],
    95: [128, 134, 135, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153],
    96: [137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155],
    97: [136, 137, 139, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 156],
    98: [138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158],
    99: [141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158],
    100: [141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159],
    101: [143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159],
    102: [146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 160],
    103: [149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 161, 163],
    104: [149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 161, 163],
    105: [150, 151, 152, 153, 154, 155, 156, 157, 158, 161, 162, 163, 165],
    106: [152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 163, 165],
    107: [153, 154, 155, 156, 157, 158, 159, 160, 163, 164, 165, 167, 171],
    108: [155, 156, 157, 158, 159, 160, 161, 162, 163, 165, 167, 169, 170],
    109: [157, 159, 161, 165, 166, 167, 168, 169, 173],
    110: [157, 159, 160, 161, 163, 167, 169, 170, 171, 172],
    111: [161, 163, 167, 168, 169, 170, 171, 175],
    112: [165, 169, 170, 171, 172, 173, 174],
    113: [165, 169, 170, 171, 172, 173, 177],
    114: [170, 171, 172, 173, 174, 175, 176],
    115: [172, 173, 174, 175],
    116: [174, 175, 176, 177, 178],
    117: [176, 177],
    118: [176],
}

KNOWN_ANIONS = {
    1:  [1],          # H⁻ exists
    2:  [],           # He⁻ does not exist
    3:  [],           # Li⁻ unstable
    4:  [],           # Be⁻ unstable
    5:  [],           # B⁻ unstable
    6:  [2, 4],       # C²⁻ and C⁴⁻ exist (carbide, methanide)
    7:  [1, 2, 3],    # N⁻, N²⁻, N³⁻ exist (gas-phase)
    8:  [1, 2],       # O⁻, O²⁻ exist
    9:  [1],          # F⁻ exists
    10: [],           # Ne⁻ does not exist
    11: [],           # Na⁻ unstable
    12: [],           # Mg⁻ unstable
    13: [],           # Al⁻ unstable
    14: [2],          # Si²⁻ exists
    15: [1, 2, 3],    # P⁻, P²⁻, P³⁻ exist
    16: [1, 2],       # S⁻, S²⁻ exist
    17: [1],          # Cl⁻ exists
    18: [],           # Ar⁻ does not exist
    19: [],           # K⁻ unstable
    20: [],           # Ca⁻ unstable
    21: [],           # Sc⁻ unstable
    22: [],           # Ti⁻ unstable
    23: [],           # V⁻ unstable
    24: [],           # Cr⁻ unstable
    25: [],           # Mn⁻ unstable
    26: [],           # Fe⁻ unstable
    27: [],           # Co⁻ unstable
    28: [],           # Ni⁻ unstable
    29: [],           # Cu⁻ unstable
    30: [],           # Zn⁻ unstable
    31: [],           # Ga⁻ unstable
    32: [2],          # Ge²⁻ exists
    33: [1, 2, 3],    # As⁻, As²⁻, As³⁻ exist
    34: [1, 2],       # Se⁻, Se²⁻ exist
    35: [1],          # Br⁻ exists
    36: [1],          # Kr⁻ exists (weakly bound)
    37: [],           # Rb⁻ unstable
    38: [],           # Sr⁻ unstable
    39: [],           # Y⁻ unstable
    40: [],           # Zr⁻ unstable
    41: [],           # Nb⁻ unstable
    42: [],           # Mo⁻ unstable
    43: [],           # Tc⁻ unstable
    44: [],           # Ru⁻ unstable
    45: [],           # Rh⁻ unstable
    46: [],           # Pd⁻ unstable
    47: [],           # Ag⁻ unstable
    48: [],           # Cd⁻ unstable
    49: [],           # In⁻ unstable
    50: [2],          # Sn²⁻ exists
    51: [1, 2, 3],    # Sb⁻, Sb²⁻, Sb³⁻ exist
    52: [1, 2],       # Te⁻, Te²⁻ exist
    53: [1],          # I⁻ exists
    54: [1],          # Xe⁻ exists (weakly bound)
    55: [],           # Cs⁻ unstable
    56: [],           # Ba⁻ unstable
    57: [],           # La⁻ unstable
    58: [],           # Ce⁻ unstable
    59: [],           # Pr⁻ unstable
    60: [],           # Nd⁻ unstable
    61: [],           # Pm⁻ unstable
    62: [],           # Sm⁻ unstable
    63: [],           # Eu⁻ unstable
    64: [],           # Gd⁻ unstable
    65: [],           # Tb⁻ unstable
    66: [],           # Dy⁻ unstable
    67: [],           # Ho⁻ unstable
    68: [],           # Er⁻ unstable
    69: [],           # Tm⁻ unstable
    70: [],           # Yb⁻ unstable
    71: [],           # Lu⁻ unstable
    72: [],           # Hf⁻ unstable
    73: [],           # Ta⁻ unstable
    74: [],           # W⁻ unstable
    75: [],           # Re⁻ unstable
    76: [],           # Os⁻ unstable
    77: [],           # Ir⁻ unstable
    78: [],           # Pt⁻ unstable
    79: [],           # Au⁻ unstable
    80: [],           # Hg⁻ unstable
    81: [],           # Tl⁻ unstable
    82: [2],          # Pb²⁻ exists
    83: [1, 2, 3],    # Bi⁻, Bi²⁻, Bi³⁻ exist
    84: [1, 2],       # Po⁻, Po²⁻ exist
    85: [1],          # At⁻ exists
    86: [],           # Rn⁻ unstable
    87: [],           # Fr⁻ unstable
    88: [],           # Ra⁻ unstable
    89: [],           # Ac⁻ unstable
    90: [],           # Th⁻ unstable
    91: [],           # Pa⁻ unstable
    92: [],           # U⁻ unstable
    93: [],           # Np⁻ unstable
    94: [],           # Pu⁻ unstable
    95: [],           # Am⁻ unstable
    96: [],           # Cm⁻ unstable
    97: [],           # Bk⁻ unstable
    98: [],           # Cf⁻ unstable
    99: [],           # Es⁻ unstable
    100: [],          # Fm⁻ unstable
    101: [],          # Md⁻ unstable
    102: [],          # No⁻ unstable
    103: [],          # Lr⁻ unstable
    104: [],          # Rf⁻ unstable
    105: [],          # Db⁻ unstable
    106: [],          # Sg⁻ unstable
    107: [],          # Bh⁻ unstable
    108: [],          # Hs⁻ unstable
    109: [],          # Mt⁻ unstable
    110: [],          # Ds⁻ unstable
    111: [],          # Rg⁻ unstable
    112: [],          # Cn⁻ unstable
    113: [],          # Nh⁻ unstable
    114: [],          # Fl⁻ unstable
    115: [],          # Mc⁻ unstable
    116: [],          # Lv⁻ unstable
    117: [1],         # Ts⁻ exists (halogen)
    118: [],          # Og⁻ unstable
}

ELEMENT_SYMBOL = {
    0:  "–",
    1:  "H",
    2:  "He",
    3:  "Li",
    4:  "Be",
    5:  "B",
    6:  "C",
    7:  "N",
    8:  "O",
    9:  "F",
    10: "Ne",
    11: "Na",
    12: "Mg",
    13: "Al",
    14: "Si",
    15: "P",
    16: "S",
    17: "Cl",
    18: "Ar",
    19: "K",
    20: "Ca",
    21: "Sc",
    22: "Ti",
    23: "V",
    24: "Cr",
    25: "Mn",
    26: "Fe",
    27: "Co",
    28: "Ni",
    29: "Cu",
    30: "Zn",
    31: "Ga",
    32: "Ge",
    33: "As",
    34: "Se",
    35: "Br",
    36: "Kr",
    37: "Rb",
    38: "Sr",
    39: "Y",
    40: "Zr",
    41: "Nb",
    42: "Mo",
    43: "Tc",
    44: "Ru",
    45: "Rh",
    46: "Pd",
    47: "Ag",
    48: "Cd",
    49: "In",
    50: "Sn",
    51: "Sb",
    52: "Te",
    53: "I",
    54: "Xe",
    55: "Cs",
    56: "Ba",
    57: "La",
    58: "Ce",
    59: "Pr",
    60: "Nd",
    61: "Pm",
    62: "Sm",
    63: "Eu",
    64: "Gd",
    65: "Tb",
    66: "Dy",
    67: "Ho",
    68: "Er",
    69: "Tm",
    70: "Yb",
    71: "Lu",
    72: "Hf",
    73: "Ta",
    74: "W",
    75: "Re",
    76: "Os",
    77: "Ir",
    78: "Pt",
    79: "Au",
    80: "Hg",
    81: "Tl",
    82: "Pb",
    83: "Bi",
    84: "Po",
    85: "At",
    86: "Rn",
    87: "Fr",
    88: "Ra",
    89: "Ac",
    90: "Th",
    91: "Pa",
    92: "U",
    93: "Np",
    94: "Pu",
    95: "Am",
    96: "Cm",
    97: "Bk",
    98: "Cf",
    99: "Es",
    100: "Fm",
    101: "Md",
    102: "No",
    103: "Lr",
    104: "Rf",
    105: "Db",
    106: "Sg",
    107: "Bh",
    108: "Hs",
    109: "Mt",
    110: "Ds",
    111: "Rg",
    112: "Cn",
    113: "Nh",
    114: "Fl",
    115: "Mc",
    116: "Lv",
    117: "Ts",
    118: "Og",
}



CATEGORY_COLOR = {
    "nonmetal": (80, 180, 80),
    "noble": (120, 120, 255),
    "alkali": (255, 160, 80),
    "alkaline": (255, 200, 120),
    "metalloid": (120, 200, 120),
    "halogen": (255, 120, 120),
    "metal": (180, 180, 180),
    "transition": (200, 160, 255),
    "lanth": (255, 200, 255),
    "actin": (255, 160, 200),
}

ELEMENT_DATA = {
    1:   {"symbol":"H",   "name":"Hydrogen",       "category":"nonmetal",   "period":1, "group":1,   "block":"s", "electronegativity":2.20, "radius":31,  "state":"Gas",     "most_common_A":1,   "has_stable_isotopes":True},
    2:   {"symbol":"He",  "name":"Helium",          "category":"noble",      "period":1, "group":18,  "block":"s", "electronegativity":None, "radius":28,  "state":"Gas",     "most_common_A":4,   "has_stable_isotopes":True},
    3:   {"symbol":"Li",  "name":"Lithium",         "category":"alkali",     "period":2, "group":1,   "block":"s", "electronegativity":0.98, "radius":128, "state":"Solid",   "most_common_A":7,   "has_stable_isotopes":True},
    4:   {"symbol":"Be",  "name":"Beryllium",       "category":"alkaline",   "period":2, "group":2,   "block":"s", "electronegativity":1.57, "radius":96,  "state":"Solid",   "most_common_A":9,   "has_stable_isotopes":True},
    5:   {"symbol":"B",   "name":"Boron",           "category":"metalloid",  "period":2, "group":13,  "block":"p", "electronegativity":2.04, "radius":84,  "state":"Solid",   "most_common_A":11,  "has_stable_isotopes":True},
    6:   {"symbol":"C",   "name":"Carbon",          "category":"nonmetal",   "period":2, "group":14,  "block":"p", "electronegativity":2.55, "radius":77,  "state":"Solid",   "most_common_A":12,  "has_stable_isotopes":True},
    7:   {"symbol":"N",   "name":"Nitrogen",        "category":"nonmetal",   "period":2, "group":15,  "block":"p", "electronegativity":3.04, "radius":71,  "state":"Gas",     "most_common_A":14,  "has_stable_isotopes":True},
    8:   {"symbol":"O",   "name":"Oxygen",          "category":"nonmetal",   "period":2, "group":16,  "block":"p", "electronegativity":3.44, "radius":66,  "state":"Gas",     "most_common_A":16,  "has_stable_isotopes":True},
    9:   {"symbol":"F",   "name":"Fluorine",        "category":"halogen",    "period":2, "group":17,  "block":"p", "electronegativity":3.98, "radius":64,  "state":"Gas",     "most_common_A":19,  "has_stable_isotopes":True},
    10:  {"symbol":"Ne",  "name":"Neon",            "category":"noble",      "period":2, "group":18,  "block":"p", "electronegativity":None, "radius":58,  "state":"Gas",     "most_common_A":20,  "has_stable_isotopes":True},
    11:  {"symbol":"Na",  "name":"Sodium",          "category":"alkali",     "period":3, "group":1,   "block":"s", "electronegativity":0.93, "radius":166, "state":"Solid",   "most_common_A":23,  "has_stable_isotopes":True},
    12:  {"symbol":"Mg",  "name":"Magnesium",       "category":"alkaline",   "period":3, "group":2,   "block":"s", "electronegativity":1.31, "radius":141, "state":"Solid",   "most_common_A":24,  "has_stable_isotopes":True},
    13:  {"symbol":"Al",  "name":"Aluminium",       "category":"metal",      "period":3, "group":13,  "block":"p", "electronegativity":1.61, "radius":121, "state":"Solid",   "most_common_A":27,  "has_stable_isotopes":True},
    14:  {"symbol":"Si",  "name":"Silicon",         "category":"metalloid",  "period":3, "group":14,  "block":"p", "electronegativity":1.90, "radius":111, "state":"Solid",   "most_common_A":28,  "has_stable_isotopes":True},
    15:  {"symbol":"P",   "name":"Phosphorus",      "category":"nonmetal",   "period":3, "group":15,  "block":"p", "electronegativity":2.19, "radius":107, "state":"Solid",   "most_common_A":31,  "has_stable_isotopes":True},
    16:  {"symbol":"S",   "name":"Sulfur",          "category":"nonmetal",   "period":3, "group":16,  "block":"p", "electronegativity":2.58, "radius":105, "state":"Solid",   "most_common_A":32,  "has_stable_isotopes":True},
    17:  {"symbol":"Cl",  "name":"Chlorine",        "category":"halogen",    "period":3, "group":17,  "block":"p", "electronegativity":3.16, "radius":102, "state":"Gas",     "most_common_A":35,  "has_stable_isotopes":True},
    18:  {"symbol":"Ar",  "name":"Argon",           "category":"noble",      "period":3, "group":18,  "block":"p", "electronegativity":None, "radius":106, "state":"Gas",     "most_common_A":40,  "has_stable_isotopes":True},
    19:  {"symbol":"K",   "name":"Potassium",       "category":"alkali",     "period":4, "group":1,   "block":"s", "electronegativity":0.82, "radius":203, "state":"Solid",   "most_common_A":39,  "has_stable_isotopes":True},
    20:  {"symbol":"Ca",  "name":"Calcium",         "category":"alkaline",   "period":4, "group":2,   "block":"s", "electronegativity":1.00, "radius":176, "state":"Solid",   "most_common_A":40,  "has_stable_isotopes":True},
    21:  {"symbol":"Sc",  "name":"Scandium",        "category":"transition", "period":4, "group":3,   "block":"d", "electronegativity":1.36, "radius":170, "state":"Solid",   "most_common_A":45,  "has_stable_isotopes":True},
    22:  {"symbol":"Ti",  "name":"Titanium",        "category":"transition", "period":4, "group":4,   "block":"d", "electronegativity":1.54, "radius":160, "state":"Solid",   "most_common_A":48,  "has_stable_isotopes":True},
    23:  {"symbol":"V",   "name":"Vanadium",        "category":"transition", "period":4, "group":5,   "block":"d", "electronegativity":1.63, "radius":153, "state":"Solid",   "most_common_A":51,  "has_stable_isotopes":True},
    24:  {"symbol":"Cr",  "name":"Chromium",        "category":"transition", "period":4, "group":6,   "block":"d", "electronegativity":1.66, "radius":139, "state":"Solid",   "most_common_A":52,  "has_stable_isotopes":True},
    25:  {"symbol":"Mn",  "name":"Manganese",       "category":"transition", "period":4, "group":7,   "block":"d", "electronegativity":1.55, "radius":137, "state":"Solid",   "most_common_A":55,  "has_stable_isotopes":True},
    26:  {"symbol":"Fe",  "name":"Iron",            "category":"transition", "period":4, "group":8,   "block":"d", "electronegativity":1.83, "radius":126, "state":"Solid",   "most_common_A":56,  "has_stable_isotopes":True},
    27:  {"symbol":"Co",  "name":"Cobalt",          "category":"transition", "period":4, "group":9,   "block":"d", "electronegativity":1.88, "radius":125, "state":"Solid",   "most_common_A":59,  "has_stable_isotopes":True},
    28:  {"symbol":"Ni",  "name":"Nickel",          "category":"transition", "period":4, "group":10,  "block":"d", "electronegativity":1.91, "radius":124, "state":"Solid",   "most_common_A":58,  "has_stable_isotopes":True},
    29:  {"symbol":"Cu",  "name":"Copper",          "category":"transition", "period":4, "group":11,  "block":"d", "electronegativity":1.90, "radius":128, "state":"Solid",   "most_common_A":63,  "has_stable_isotopes":True},
    30:  {"symbol":"Zn",  "name":"Zinc",            "category":"transition", "period":4, "group":12,  "block":"d", "electronegativity":1.65, "radius":122, "state":"Solid",   "most_common_A":64,  "has_stable_isotopes":True},
    31:  {"symbol":"Ga",  "name":"Gallium",         "category":"metal",      "period":4, "group":13,  "block":"p", "electronegativity":1.81, "radius":122, "state":"Solid",   "most_common_A":69,  "has_stable_isotopes":True},
    32:  {"symbol":"Ge",  "name":"Germanium",       "category":"metalloid",  "period":4, "group":14,  "block":"p", "electronegativity":2.01, "radius":120, "state":"Solid",   "most_common_A":74,  "has_stable_isotopes":True},
    33:  {"symbol":"As",  "name":"Arsenic",         "category":"metalloid",  "period":4, "group":15,  "block":"p", "electronegativity":2.18, "radius":119, "state":"Solid",   "most_common_A":75,  "has_stable_isotopes":True},
    34:  {"symbol":"Se",  "name":"Selenium",        "category":"nonmetal",   "period":4, "group":16,  "block":"p", "electronegativity":2.55, "radius":120, "state":"Solid",   "most_common_A":80,  "has_stable_isotopes":True},
    35:  {"symbol":"Br",  "name":"Bromine",         "category":"halogen",    "period":4, "group":17,  "block":"p", "electronegativity":2.96, "radius":120, "state":"Liquid",  "most_common_A":79,  "has_stable_isotopes":True},
    36:  {"symbol":"Kr",  "name":"Krypton",         "category":"noble",      "period":4, "group":18,  "block":"p", "electronegativity":3.00, "radius":116, "state":"Gas",     "most_common_A":84,  "has_stable_isotopes":True},
    37:  {"symbol":"Rb",  "name":"Rubidium",        "category":"alkali",     "period":5, "group":1,   "block":"s", "electronegativity":0.82, "radius":220, "state":"Solid",   "most_common_A":85,  "has_stable_isotopes":True},
    38:  {"symbol":"Sr",  "name":"Strontium",       "category":"alkaline",   "period":5, "group":2,   "block":"s", "electronegativity":0.95, "radius":195, "state":"Solid",   "most_common_A":88,  "has_stable_isotopes":True},
    39:  {"symbol":"Y",   "name":"Yttrium",         "category":"transition", "period":5, "group":3,   "block":"d", "electronegativity":1.22, "radius":190, "state":"Solid",   "most_common_A":89,  "has_stable_isotopes":True},
    40:  {"symbol":"Zr",  "name":"Zirconium",       "category":"transition", "period":5, "group":4,   "block":"d", "electronegativity":1.33, "radius":175, "state":"Solid",   "most_common_A":90,  "has_stable_isotopes":True},
    41:  {"symbol":"Nb",  "name":"Niobium",         "category":"transition", "period":5, "group":5,   "block":"d", "electronegativity":1.60, "radius":164, "state":"Solid",   "most_common_A":93,  "has_stable_isotopes":True},
    42:  {"symbol":"Mo",  "name":"Molybdenum",      "category":"transition", "period":5, "group":6,   "block":"d", "electronegativity":2.16, "radius":154, "state":"Solid",   "most_common_A":98,  "has_stable_isotopes":True},
    43:  {"symbol":"Tc",  "name":"Technetium",      "category":"transition", "period":5, "group":7,   "block":"d", "electronegativity":1.90, "radius":147, "state":"Solid",   "most_common_A":98,  "has_stable_isotopes":False},
    44:  {"symbol":"Ru",  "name":"Ruthenium",       "category":"transition", "period":5, "group":8,   "block":"d", "electronegativity":2.20, "radius":146, "state":"Solid",   "most_common_A":102, "has_stable_isotopes":True},
    45:  {"symbol":"Rh",  "name":"Rhodium",         "category":"transition", "period":5, "group":9,   "block":"d", "electronegativity":2.28, "radius":142, "state":"Solid",   "most_common_A":103, "has_stable_isotopes":True},
    46:  {"symbol":"Pd",  "name":"Palladium",       "category":"transition", "period":5, "group":10,  "block":"d", "electronegativity":2.20, "radius":139, "state":"Solid",   "most_common_A":106, "has_stable_isotopes":True},
    47:  {"symbol":"Ag",  "name":"Silver",          "category":"transition", "period":5, "group":11,  "block":"d", "electronegativity":1.93, "radius":145, "state":"Solid",   "most_common_A":107, "has_stable_isotopes":True},
    48:  {"symbol":"Cd",  "name":"Cadmium",         "category":"transition", "period":5, "group":12,  "block":"d", "electronegativity":1.69, "radius":144, "state":"Solid",   "most_common_A":114, "has_stable_isotopes":True},
    49:  {"symbol":"In",  "name":"Indium",          "category":"metal",      "period":5, "group":13,  "block":"p", "electronegativity":1.78, "radius":142, "state":"Solid",   "most_common_A":115, "has_stable_isotopes":True},
    50:  {"symbol":"Sn",  "name":"Tin",             "category":"metal",      "period":5, "group":14,  "block":"p", "electronegativity":1.96, "radius":139, "state":"Solid",   "most_common_A":120, "has_stable_isotopes":True},
    51:  {"symbol":"Sb",  "name":"Antimony",        "category":"metalloid",  "period":5, "group":15,  "block":"p", "electronegativity":2.05, "radius":139, "state":"Solid",   "most_common_A":121, "has_stable_isotopes":True},
    52:  {"symbol":"Te",  "name":"Tellurium",       "category":"metalloid",  "period":5, "group":16,  "block":"p", "electronegativity":2.10, "radius":138, "state":"Solid",   "most_common_A":130, "has_stable_isotopes":True},
    53:  {"symbol":"I",   "name":"Iodine",          "category":"halogen",    "period":5, "group":17,  "block":"p", "electronegativity":2.66, "radius":139, "state":"Solid",   "most_common_A":127, "has_stable_isotopes":True},
    54:  {"symbol":"Xe",  "name":"Xenon",           "category":"noble",      "period":5, "group":18,  "block":"p", "electronegativity":2.60, "radius":140, "state":"Gas",     "most_common_A":132, "has_stable_isotopes":True},
    55:  {"symbol":"Cs",  "name":"Caesium",         "category":"alkali",     "period":6, "group":1,   "block":"s", "electronegativity":0.79, "radius":244, "state":"Solid",   "most_common_A":133, "has_stable_isotopes":True},
    56:  {"symbol":"Ba",  "name":"Barium",          "category":"alkaline",   "period":6, "group":2,   "block":"s", "electronegativity":0.89, "radius":215, "state":"Solid",   "most_common_A":138, "has_stable_isotopes":True},
    57:  {"symbol":"La",  "name":"Lanthanum",       "category":"lanth",      "period":6, "group":3,   "block":"f", "electronegativity":1.10, "radius":207, "state":"Solid",   "most_common_A":139, "has_stable_isotopes":True},
    58:  {"symbol":"Ce",  "name":"Cerium",          "category":"lanth",      "period":6, "group":3,   "block":"f", "electronegativity":1.12, "radius":204, "state":"Solid",   "most_common_A":140, "has_stable_isotopes":True},
    59:  {"symbol":"Pr",  "name":"Praseodymium",    "category":"lanth",      "period":6, "group":3,   "block":"f", "electronegativity":1.13, "radius":203, "state":"Solid",   "most_common_A":141, "has_stable_isotopes":True},
    60:  {"symbol":"Nd",  "name":"Neodymium",       "category":"lanth",      "period":6, "group":3,   "block":"f", "electronegativity":1.14, "radius":201, "state":"Solid",   "most_common_A":142, "has_stable_isotopes":True},
    61:  {"symbol":"Pm",  "name":"Promethium",      "category":"lanth",      "period":6, "group":3,   "block":"f", "electronegativity":1.13, "radius":199, "state":"Solid",   "most_common_A":145, "has_stable_isotopes":False},
    62:  {"symbol":"Sm",  "name":"Samarium",        "category":"lanth",      "period":6, "group":3,   "block":"f", "electronegativity":1.17, "radius":198, "state":"Solid",   "most_common_A":152, "has_stable_isotopes":True},
    63:  {"symbol":"Eu",  "name":"Europium",        "category":"lanth",      "period":6, "group":3,   "block":"f", "electronegativity":1.20, "radius":198, "state":"Solid",   "most_common_A":153, "has_stable_isotopes":True},
    64:  {"symbol":"Gd",  "name":"Gadolinium",      "category":"lanth",      "period":6, "group":3,   "block":"f", "electronegativity":1.20, "radius":196, "state":"Solid",   "most_common_A":158, "has_stable_isotopes":True},
    65:  {"symbol":"Tb",  "name":"Terbium",         "category":"lanth",      "period":6, "group":3,   "block":"f", "electronegativity":1.20, "radius":194, "state":"Solid",   "most_common_A":159, "has_stable_isotopes":True},
    66:  {"symbol":"Dy",  "name":"Dysprosium",      "category":"lanth",      "period":6, "group":3,   "block":"f", "electronegativity":1.22, "radius":192, "state":"Solid",   "most_common_A":164, "has_stable_isotopes":True},
    67:  {"symbol":"Ho",  "name":"Holmium",         "category":"lanth",      "period":6, "group":3,   "block":"f", "electronegativity":1.23, "radius":192, "state":"Solid",   "most_common_A":165, "has_stable_isotopes":True},
    68:  {"symbol":"Er",  "name":"Erbium",          "category":"lanth",      "period":6, "group":3,   "block":"f", "electronegativity":1.24, "radius":189, "state":"Solid",   "most_common_A":166, "has_stable_isotopes":True},
    69:  {"symbol":"Tm",  "name":"Thulium",         "category":"lanth",      "period":6, "group":3,   "block":"f", "electronegativity":1.25, "radius":190, "state":"Solid",   "most_common_A":169, "has_stable_isotopes":True},
    70:  {"symbol":"Yb",  "name":"Ytterbium",       "category":"lanth",      "period":6, "group":3,   "block":"f", "electronegativity":1.10, "radius":187, "state":"Solid",   "most_common_A":174, "has_stable_isotopes":True},
    71:  {"symbol":"Lu",  "name":"Lutetium",        "category":"lanth",      "period":6, "group":3,   "block":"f", "electronegativity":1.27, "radius":187, "state":"Solid",   "most_common_A":175, "has_stable_isotopes":True},
    72:  {"symbol":"Hf",  "name":"Hafnium",         "category":"transition", "period":6, "group":4,   "block":"d", "electronegativity":1.30, "radius":175, "state":"Solid",   "most_common_A":180, "has_stable_isotopes":True},
    73:  {"symbol":"Ta",  "name":"Tantalum",        "category":"transition", "period":6, "group":5,   "block":"d", "electronegativity":1.50, "radius":170, "state":"Solid",   "most_common_A":181, "has_stable_isotopes":True},
    74:  {"symbol":"W",   "name":"Tungsten",        "category":"transition", "period":6, "group":6,   "block":"d", "electronegativity":2.36, "radius":162, "state":"Solid",   "most_common_A":184, "has_stable_isotopes":True},
    75:  {"symbol":"Re",  "name":"Rhenium",         "category":"transition", "period":6, "group":7,   "block":"d", "electronegativity":1.90, "radius":151, "state":"Solid",   "most_common_A":187, "has_stable_isotopes":True},
    76:  {"symbol":"Os",  "name":"Osmium",          "category":"transition", "period":6, "group":8,   "block":"d", "electronegativity":2.20, "radius":144, "state":"Solid",   "most_common_A":192, "has_stable_isotopes":True},
    77:  {"symbol":"Ir",  "name":"Iridium",         "category":"transition", "period":6, "group":9,   "block":"d", "electronegativity":2.20, "radius":141, "state":"Solid",   "most_common_A":193, "has_stable_isotopes":True},
    78:  {"symbol":"Pt",  "name":"Platinum",        "category":"transition", "period":6, "group":10,  "block":"d", "electronegativity":2.28, "radius":136, "state":"Solid",   "most_common_A":195, "has_stable_isotopes":True},
    79:  {"symbol":"Au",  "name":"Gold",            "category":"transition", "period":6, "group":11,  "block":"d", "electronegativity":2.54, "radius":136, "state":"Solid",   "most_common_A":197, "has_stable_isotopes":True},
    80:  {"symbol":"Hg",  "name":"Mercury",         "category":"transition", "period":6, "group":12,  "block":"d", "electronegativity":2.00, "radius":132, "state":"Liquid",  "most_common_A":202, "has_stable_isotopes":True},
    81:  {"symbol":"Tl",  "name":"Thallium",        "category":"metal",      "period":6, "group":13,  "block":"p", "electronegativity":1.62, "radius":145, "state":"Solid",   "most_common_A":205, "has_stable_isotopes":True},
    82:  {"symbol":"Pb",  "name":"Lead",            "category":"metal",      "period":6, "group":14,  "block":"p", "electronegativity":2.33, "radius":146, "state":"Solid",   "most_common_A":208, "has_stable_isotopes":True},
    83:  {"symbol":"Bi",  "name":"Bismuth",         "category":"metal",      "period":6, "group":15,  "block":"p", "electronegativity":2.02, "radius":148, "state":"Solid",   "most_common_A":209, "has_stable_isotopes":False},
    84:  {"symbol":"Po",  "name":"Polonium",        "category":"metalloid",  "period":6, "group":16,  "block":"p", "electronegativity":2.00, "radius":140, "state":"Solid",   "most_common_A":209, "has_stable_isotopes":False},
    85:  {"symbol":"At",  "name":"Astatine",        "category":"halogen",    "period":6, "group":17,  "block":"p", "electronegativity":2.20, "radius":150, "state":"Solid",   "most_common_A":210, "has_stable_isotopes":False},
    86:  {"symbol":"Rn",  "name":"Radon",           "category":"noble",      "period":6, "group":18,  "block":"p", "electronegativity":None, "radius":150, "state":"Gas",     "most_common_A":222, "has_stable_isotopes":False},
    87:  {"symbol":"Fr",  "name":"Francium",        "category":"alkali",     "period":7, "group":1,   "block":"s", "electronegativity":0.70, "radius":260, "state":"Solid",   "most_common_A":223, "has_stable_isotopes":False},
    88:  {"symbol":"Ra",  "name":"Radium",          "category":"alkaline",   "period":7, "group":2,   "block":"s", "electronegativity":0.90, "radius":221, "state":"Solid",   "most_common_A":226, "has_stable_isotopes":False},
    89:  {"symbol":"Ac",  "name":"Actinium",        "category":"actin",      "period":7, "group":3,   "block":"f", "electronegativity":1.10, "radius":215, "state":"Solid",   "most_common_A":227, "has_stable_isotopes":False},
    90:  {"symbol":"Th",  "name":"Thorium",         "category":"actin",      "period":7, "group":3,   "block":"f", "electronegativity":1.30, "radius":206, "state":"Solid",   "most_common_A":232, "has_stable_isotopes":False},
    91:  {"symbol":"Pa",  "name":"Protactinium",    "category":"actin",      "period":7, "group":3,   "block":"f", "electronegativity":1.50, "radius":200, "state":"Solid",   "most_common_A":231, "has_stable_isotopes":False},
    92:  {"symbol":"U",   "name":"Uranium",         "category":"actin",      "period":7, "group":3,   "block":"f", "electronegativity":1.38, "radius":196, "state":"Solid",   "most_common_A":238, "has_stable_isotopes":False},
    93:  {"symbol":"Np",  "name":"Neptunium",       "category":"actin",      "period":7, "group":3,   "block":"f", "electronegativity":1.36, "radius":190, "state":"Solid",   "most_common_A":237, "has_stable_isotopes":False},
    94:  {"symbol":"Pu",  "name":"Plutonium",       "category":"actin",      "period":7, "group":3,   "block":"f", "electronegativity":1.28, "radius":187, "state":"Solid",   "most_common_A":244, "has_stable_isotopes":False},
    95:  {"symbol":"Am",  "name":"Americium",       "category":"actin",      "period":7, "group":3,   "block":"f", "electronegativity":1.30, "radius":180, "state":"Solid",   "most_common_A":243, "has_stable_isotopes":False},
    96:  {"symbol":"Cm",  "name":"Curium",          "category":"actin",      "period":7, "group":3,   "block":"f", "electronegativity":1.30, "radius":169, "state":"Solid",   "most_common_A":247, "has_stable_isotopes":False},
    97:  {"symbol":"Bk",  "name":"Berkelium",       "category":"actin",      "period":7, "group":3,   "block":"f", "electronegativity":1.30, "radius":None,"state":"Solid",   "most_common_A":247, "has_stable_isotopes":False},
    98:  {"symbol":"Cf",  "name":"Californium",     "category":"actin",      "period":7, "group":3,   "block":"f", "electronegativity":1.30, "radius":None,"state":"Solid",   "most_common_A":251, "has_stable_isotopes":False},
    99:  {"symbol":"Es",  "name":"Einsteinium",     "category":"actin",      "period":7, "group":3,   "block":"f", "electronegativity":1.30, "radius":None,"state":"Solid",   "most_common_A":252, "has_stable_isotopes":False},
    100: {"symbol":"Fm",  "name":"Fermium",         "category":"actin",      "period":7, "group":3,   "block":"f", "electronegativity":1.30, "radius":None,"state":"Solid",   "most_common_A":257, "has_stable_isotopes":False},
    101: {"symbol":"Md",  "name":"Mendelevium",     "category":"actin",      "period":7, "group":3,   "block":"f", "electronegativity":1.30, "radius":None,"state":"Solid",   "most_common_A":258, "has_stable_isotopes":False},
    102: {"symbol":"No",  "name":"Nobelium",        "category":"actin",      "period":7, "group":3,   "block":"f", "electronegativity":1.30, "radius":None,"state":"Solid",   "most_common_A":259, "has_stable_isotopes":False},
    103: {"symbol":"Lr",  "name":"Lawrencium",      "category":"actin",      "period":7, "group":3,   "block":"f", "electronegativity":1.30, "radius":None,"state":"Solid",   "most_common_A":266, "has_stable_isotopes":False},
    104: {"symbol":"Rf",  "name":"Rutherfordium",   "category":"transition", "period":7, "group":4,   "block":"d", "electronegativity":None, "radius":None,"state":"Solid",   "most_common_A":267, "has_stable_isotopes":False},
    105: {"symbol":"Db",  "name":"Dubnium",         "category":"transition", "period":7, "group":5,   "block":"d", "electronegativity":None, "radius":None,"state":"Solid",   "most_common_A":268, "has_stable_isotopes":False},
    106: {"symbol":"Sg",  "name":"Seaborgium",      "category":"transition", "period":7, "group":6,   "block":"d", "electronegativity":None, "radius":None,"state":"Solid",   "most_common_A":271, "has_stable_isotopes":False},
    107: {"symbol":"Bh",  "name":"Bohrium",         "category":"transition", "period":7, "group":7,   "block":"d", "electronegativity":None, "radius":None,"state":"Solid",   "most_common_A":272, "has_stable_isotopes":False},
    108: {"symbol":"Hs",  "name":"Hassium",         "category":"transition", "period":7, "group":8,   "block":"d", "electronegativity":None, "radius":None,"state":"Solid",   "most_common_A":277, "has_stable_isotopes":False},
    109: {"symbol":"Mt",  "name":"Meitnerium",      "category":"transition", "period":7, "group":9,   "block":"d", "electronegativity":None, "radius":None,"state":"Unknown",  "most_common_A":278, "has_stable_isotopes":False},
    110: {"symbol":"Ds",  "name":"Darmstadtium",    "category":"transition", "period":7, "group":10,  "block":"d", "electronegativity":None, "radius":None,"state":"Unknown",  "most_common_A":281, "has_stable_isotopes":False},
    111: {"symbol":"Rg",  "name":"Roentgenium",     "category":"transition", "period":7, "group":11,  "block":"d", "electronegativity":None, "radius":None,"state":"Unknown",  "most_common_A":282, "has_stable_isotopes":False},
    112: {"symbol":"Cn",  "name":"Copernicium",     "category":"transition", "period":7, "group":12,  "block":"d", "electronegativity":None, "radius":None,"state":"Unknown",  "most_common_A":285, "has_stable_isotopes":False},
    113: {"symbol":"Nh",  "name":"Nihonium",        "category":"metal",      "period":7, "group":13,  "block":"p", "electronegativity":None, "radius":None,"state":"Unknown",  "most_common_A":286, "has_stable_isotopes":False},
    114: {"symbol":"Fl",  "name":"Flerovium",       "category":"metal",      "period":7, "group":14,  "block":"p", "electronegativity":None, "radius":None,"state":"Unknown",  "most_common_A":289, "has_stable_isotopes":False},
    115: {"symbol":"Mc",  "name":"Moscovium",       "category":"metal",      "period":7, "group":15,  "block":"p", "electronegativity":None, "radius":None,"state":"Unknown",  "most_common_A":290, "has_stable_isotopes":False},
    116: {"symbol":"Lv",  "name":"Livermorium",     "category":"metal",      "period":7, "group":16,  "block":"p", "electronegativity":None, "radius":None,"state":"Unknown",  "most_common_A":293, "has_stable_isotopes":False},
    117: {"symbol":"Ts",  "name":"Tennessine",      "category":"halogen",    "period":7, "group":17,  "block":"p", "electronegativity":None, "radius":None,"state":"Unknown",  "most_common_A":294, "has_stable_isotopes":False},
    118: {"symbol":"Og",  "name":"Oganesson",       "category":"noble",      "period":7, "group":18,  "block":"p", "electronegativity":None, "radius":None,"state":"Unknown",  "most_common_A":294, "has_stable_isotopes":False},
}


# ── ISOTOPE_DATA ──────────────────────────────────────────────────────────────
# Key: (Z, A)  →  {"stable": bool}
# Covers all isotopes listed in KNOWN_NEUTRONS above.
# stable=True  → known stable nuclide
# stable=False → radioactive

ISOTOPE_DATA = {
    # Z=0 (neutron / bare neutron clusters — all unstable)
    (0,1):False,(0,4):False,(0,6):False,

    # Z=1  Hydrogen
    (1,1):True, (1,2):True, (1,3):False,(1,4):False,(1,5):False,(1,6):False,(1,7):False,

    # Z=2  Helium
    (2,3):True, (2,4):True, (2,5):False,(2,6):False,(2,7):False,(2,8):False,(2,9):False,(2,10):False,

    # Z=3  Lithium
    (3,4):False,(3,5):False,(3,6):True, (3,7):True, (3,8):False,(3,9):False,(3,10):False,(3,11):False,(3,12):False,

    # Z=4  Beryllium
    (4,6):False,(4,7):False,(4,8):False,(4,9):True, (4,10):False,(4,11):False,(4,12):False,(4,13):False,(4,14):False,(4,15):False,(4,16):False,

    # Z=5  Boron
    (5,7):False,(5,8):False,(5,9):False,(5,10):True,(5,11):True,(5,12):False,(5,13):False,(5,14):False,(5,15):False,(5,16):False,(5,17):False,(5,18):False,(5,19):False,(5,20):False,(5,21):False,

    # Z=6  Carbon
    (6,8):False,(6,9):False,(6,10):False,(6,11):False,(6,12):True,(6,13):True,(6,14):False,(6,15):False,(6,16):False,(6,17):False,(6,18):False,(6,19):False,(6,20):False,(6,22):False,

    # Z=7  Nitrogen
    (7,10):False,(7,11):False,(7,12):False,(7,13):False,(7,14):True,(7,15):True,(7,16):False,(7,17):False,(7,18):False,(7,19):False,(7,20):False,(7,21):False,(7,22):False,

    # Z=8  Oxygen
    (8,11):False,(8,12):False,(8,13):False,(8,14):False,(8,15):False,(8,16):True,(8,17):True,(8,18):True,(8,19):False,(8,20):False,(8,21):False,(8,22):False,(8,23):False,(8,24):False,(8,25):False,(8,26):False,

    # Z=9  Fluorine
    (9,13):False,(9,14):False,(9,15):False,(9,16):False,(9,17):False,(9,18):False,(9,19):True,(9,20):False,(9,21):False,(9,22):False,(9,23):False,(9,24):False,(9,25):False,(9,26):False,(9,27):False,(9,28):False,(9,29):False,(9,30):False,(9,31):False,

    # Z=10  Neon
    (10,15):False,(10,16):False,(10,17):False,(10,18):False,(10,19):False,(10,20):True,(10,21):True,(10,22):True,(10,23):False,(10,24):False,(10,25):False,(10,26):False,(10,27):False,(10,28):False,(10,29):False,(10,30):False,(10,31):False,(10,32):False,

    # Z=11  Sodium
    (11,17):False,(11,18):False,(11,19):False,(11,20):False,(11,21):False,(11,22):False,(11,23):True,(11,24):False,(11,25):False,(11,26):False,(11,27):False,(11,28):False,(11,29):False,(11,30):False,(11,31):False,(11,32):False,(11,33):False,(11,34):False,(11,35):False,(11,36):False,(11,37):False,

    # Z=12  Magnesium
    (12,18):False,(12,19):False,(12,20):False,(12,21):False,(12,22):False,(12,23):False,(12,24):True,(12,25):True,(12,26):True,(12,27):False,(12,28):False,(12,29):False,(12,30):False,(12,31):False,(12,32):False,(12,33):False,(12,34):False,(12,35):False,(12,36):False,(12,37):False,(12,38):False,(12,39):False,(12,40):False,

    # Z=13  Aluminium
    (13,21):False,(13,22):False,(13,23):False,(13,24):False,(13,25):False,(13,26):False,(13,27):True,(13,28):False,(13,29):False,(13,30):False,(13,31):False,(13,32):False,(13,33):False,(13,34):False,(13,35):False,(13,36):False,(13,37):False,(13,38):False,(13,39):False,(13,40):False,(13,41):False,(13,42):False,(13,43):False,

    # Z=14  Silicon
    (14,22):False,(14,23):False,(14,24):False,(14,25):False,(14,26):False,(14,27):False,(14,28):True,(14,29):True,(14,30):True,(14,31):False,(14,32):False,(14,33):False,(14,34):False,(14,35):False,(14,36):False,(14,37):False,(14,38):False,(14,39):False,(14,40):False,(14,41):False,(14,42):False,(14,43):False,(14,44):False,

    # Z=15  Phosphorus
    (15,25):False,(15,26):False,(15,27):False,(15,28):False,(15,29):False,(15,30):False,(15,31):True,(15,32):False,(15,33):False,(15,34):False,(15,35):False,(15,36):False,(15,37):False,(15,38):False,(15,39):False,(15,40):False,(15,41):False,(15,42):False,(15,43):False,(15,44):False,(15,45):False,(15,46):False,

    # Z=16  Sulfur
    (16,26):False,(16,27):False,(16,28):False,(16,29):False,(16,30):False,(16,31):False,(16,32):True,(16,33):True,(16,34):True,(16,35):False,(16,36):True,(16,37):False,(16,38):False,(16,39):False,(16,40):False,(16,41):False,(16,42):False,(16,43):False,(16,44):False,(16,45):False,(16,46):False,(16,48):False,

    # Z=17  Chlorine
    (17,29):False,(17,30):False,(17,31):False,(17,32):False,(17,33):False,(17,34):False,(17,35):True,(17,36):False,(17,37):True,(17,38):False,(17,39):False,(17,40):False,(17,41):False,(17,42):False,(17,43):False,(17,44):False,(17,45):False,(17,46):False,(17,47):False,(17,48):False,(17,49):False,(17,50):False,(17,51):False,(17,52):False,

    # Z=18  Argon
    (18,30):False,(18,31):False,(18,32):False,(18,33):False,(18,34):False,(18,35):False,(18,36):True,(18,37):False,(18,38):True,(18,39):False,(18,40):True,(18,41):False,(18,42):False,(18,43):False,(18,44):False,(18,45):False,(18,46):False,(18,47):False,(18,48):False,(18,49):False,(18,50):False,(18,51):False,(18,52):False,

    # Z=19  Potassium
    (19,31):False,(19,33):False,(19,34):False,(19,35):False,(19,36):False,(19,37):False,(19,38):False,(19,39):True,(19,40):False,(19,41):True,(19,42):False,(19,43):False,(19,44):False,(19,45):False,(19,46):False,(19,47):False,(19,48):False,(19,49):False,(19,50):False,(19,51):False,(19,52):False,(19,53):False,(19,54):False,(19,55):False,(19,56):False,

    # Z=20  Calcium
    (20,34):False,(20,35):False,(20,36):False,(20,37):False,(20,38):False,(20,39):False,(20,40):True,(20,41):False,(20,42):True,(20,43):True,(20,44):True,(20,45):False,(20,46):True,(20,47):False,(20,48):True,(20,49):False,(20,50):False,(20,51):False,(20,52):False,(20,53):False,(20,54):False,(20,55):False,(20,56):False,(20,57):False,(20,58):False,

    # Z=21  Scandium
    (21,38):False,(21,39):False,(21,40):False,(21,41):False,(21,42):False,(21,43):False,(21,44):False,(21,45):True,(21,46):False,(21,47):False,(21,48):False,(21,49):False,(21,50):False,(21,51):False,(21,52):False,(21,53):False,(21,54):False,(21,55):False,(21,56):False,(21,57):False,(21,58):False,(21,61):False,

    # Z=22  Titanium
    (22,38):False,(22,39):False,(22,40):False,(22,41):False,(22,42):False,(22,43):False,(22,44):False,(22,45):False,(22,46):True,(22,47):True,(22,48):True,(22,49):True,(22,50):True,(22,51):False,(22,52):False,(22,53):False,(22,54):False,(22,55):False,(22,56):False,(22,57):False,(22,58):False,(22,59):False,(22,60):False,(22,61):False,(22,62):False,(22,63):False,(22,64):False,

    # Z=23  Vanadium
    (23,42):False,(23,43):False,(23,44):False,(23,45):False,(23,46):False,(23,47):False,(23,48):False,(23,49):False,(23,50):True,(23,51):True,(23,52):False,(23,53):False,(23,54):False,(23,55):False,(23,56):False,(23,57):False,(23,58):False,(23,59):False,(23,60):False,(23,61):False,(23,62):False,(23,63):False,(23,64):False,(23,65):False,(23,66):False,(23,67):False,

    # Z=24  Chromium
    (24,42):False,(24,43):False,(24,44):False,(24,45):False,(24,46):False,(24,47):False,(24,48):False,(24,49):False,(24,50):True,(24,51):False,(24,52):True,(24,53):True,(24,54):True,(24,55):False,(24,56):False,(24,57):False,(24,58):False,(24,59):False,(24,60):False,(24,61):False,(24,62):False,(24,63):False,(24,64):False,(24,65):False,(24,66):False,(24,67):False,(24,68):False,(24,69):False,(24,70):False,

    # Z=25  Manganese
    (25,44):False,(25,45):False,(25,46):False,(25,47):False,(25,48):False,(25,49):False,(25,50):False,(25,51):False,(25,52):False,(25,53):False,(25,54):False,(25,55):True,(25,56):False,(25,57):False,(25,58):False,(25,59):False,(25,60):False,(25,61):False,(25,62):False,(25,63):False,(25,64):False,(25,65):False,(25,66):False,(25,67):False,(25,68):False,(25,69):False,(25,70):False,(25,72):False,(25,73):False,

    # Z=26  Iron
    (26,45):False,(26,46):False,(26,47):False,(26,48):False,(26,49):False,(26,50):False,(26,51):False,(26,52):False,(26,53):False,(26,54):True,(26,55):False,(26,56):True,(26,57):True,(26,58):True,(26,59):False,(26,60):False,(26,61):False,(26,62):False,(26,63):False,(26,64):False,(26,65):False,(26,66):False,(26,67):False,(26,68):False,(26,69):False,(26,70):False,(26,71):False,(26,72):False,(26,73):False,(26,74):False,(26,75):False,(26,76):False,

    # Z=27  Cobalt
    (27,48):False,(27,50):False,(27,51):False,(27,52):False,(27,53):False,(27,54):False,(27,55):False,(27,56):False,(27,57):False,(27,58):False,(27,59):True,(27,60):False,(27,61):False,(27,62):False,(27,63):False,(27,64):False,(27,65):False,(27,66):False,(27,67):False,(27,68):False,(27,69):False,(27,70):False,(27,71):False,(27,72):False,(27,73):False,(27,74):False,(27,75):False,(27,76):False,

    # Z=28  Nickel
    (28,48):False,(28,49):False,(28,50):False,(28,51):False,(28,52):False,(28,53):False,(28,54):False,(28,55):False,(28,56):True,(28,57):False,(28,58):True,(28,59):False,(28,60):True,(28,61):True,(28,62):True,(28,63):False,(28,64):True,(28,65):False,(28,66):False,(28,67):False,(28,68):False,(28,69):False,(28,70):False,(28,71):False,(28,72):False,(28,73):False,(28,74):False,(28,75):False,(28,76):False,(28,77):False,(28,78):False,

    # Z=29  Copper
    (29,53):False,(29,54):False,(29,55):False,(29,56):False,(29,57):False,(29,58):False,(29,59):False,(29,60):False,(29,61):False,(29,62):False,(29,63):True,(29,64):False,(29,65):True,(29,66):False,(29,67):False,(29,68):False,(29,69):False,(29,70):False,(29,71):False,(29,72):False,(29,73):False,(29,74):False,(29,75):False,(29,76):False,(29,77):False,(29,78):False,(29,79):False,(29,80):False,(29,81):False,(29,82):False,(29,83):False,

    # Z=30  Zinc
    (30,54):False,(30,55):False,(30,56):False,(30,57):False,(30,58):False,(30,59):False,(30,60):False,(30,61):False,(30,62):False,(30,63):False,(30,64):True,(30,65):False,(30,66):True,(30,67):True,(30,68):True,(30,69):False,(30,70):True,(30,71):False,(30,72):False,(30,73):False,(30,74):False,(30,75):False,(30,76):False,(30,77):False,(30,78):False,(30,79):False,(30,80):False,(30,81):False,(30,82):False,(30,83):False,(30,84):False,(30,85):False,

    # Z=31  Gallium
    (31,59):False,(31,60):False,(31,61):False,(31,62):False,(31,63):False,(31,64):False,(31,65):False,(31,66):False,(31,67):False,(31,68):False,(31,69):True,(31,70):False,(31,71):True,(31,72):False,(31,73):False,(31,74):False,(31,75):False,(31,76):False,(31,77):False,(31,78):False,(31,79):False,(31,80):False,(31,81):False,(31,82):False,(31,83):False,(31,84):False,(31,85):False,(31,86):False,(31,87):False,

    # Z=32  Germanium
    (32,59):False,(32,60):False,(32,61):False,(32,62):False,(32,63):False,(32,64):False,(32,65):False,(32,66):False,(32,67):False,(32,68):False,(32,69):False,(32,70):True,(32,71):False,(32,72):True,(32,73):True,(32,74):True,(32,75):False,(32,76):True,(32,77):False,(32,78):False,(32,79):False,(32,80):False,(32,81):False,(32,82):False,(32,83):False,(32,84):False,(32,85):False,(32,86):False,(32,87):False,(32,88):False,(32,89):False,(32,90):False,

    # Z=33  Arsenic
    (33,63):False,(33,64):False,(33,65):False,(33,66):False,(33,67):False,(33,68):False,(33,69):False,(33,70):False,(33,71):False,(33,72):False,(33,73):False,(33,74):False,(33,75):True,(33,76):False,(33,77):False,(33,78):False,(33,79):False,(33,80):False,(33,81):False,(33,82):False,(33,83):False,(33,84):False,(33,85):False,(33,86):False,(33,87):False,(33,88):False,(33,89):False,(33,90):False,(33,91):False,(33,92):False,

    # Z=34  Selenium
    (34,63):False,(34,64):False,(34,65):False,(34,66):False,(34,67):False,(34,68):False,(34,69):False,(34,70):False,(34,71):False,(34,72):False,(34,73):False,(34,74):True,(34,75):False,(34,76):True,(34,77):True,(34,78):True,(34,79):False,(34,80):True,(34,81):False,(34,82):True,(34,83):False,(34,84):False,(34,85):False,(34,86):False,(34,87):False,(34,88):False,(34,89):False,(34,90):False,(34,91):False,(34,92):False,(34,93):False,(34,94):False,(34,95):False,

    # Z=35  Bromine
    (35,67):False,(35,68):False,(35,69):False,(35,70):False,(35,71):False,(35,72):False,(35,73):False,(35,74):False,(35,75):False,(35,76):False,(35,77):False,(35,78):False,(35,79):True,(35,80):False,(35,81):True,(35,82):False,(35,83):False,(35,84):False,(35,85):False,(35,86):False,(35,87):False,(35,88):False,(35,89):False,(35,90):False,(35,91):False,(35,92):False,(35,93):False,(35,94):False,(35,95):False,(35,96):False,(35,97):False,(35,98):False,(35,101):False,

    # Z=36  Krypton
    (36,67):False,(36,68):False,(36,69):False,(36,70):False,(36,71):False,(36,72):False,(36,73):False,(36,74):False,(36,75):False,(36,76):False,(36,77):False,(36,78):True,(36,79):False,(36,80):True,(36,81):False,(36,82):True,(36,83):True,(36,84):True,(36,85):False,(36,86):True,(36,87):False,(36,88):False,(36,89):False,(36,90):False,(36,91):False,(36,92):False,(36,93):False,(36,94):False,(36,95):False,(36,96):False,(36,97):False,(36,98):False,(36,99):False,(36,100):False,(36,101):False,(36,102):False,

    # Z=37  Rubidium
    (37,72):False,(37,73):False,(37,74):False,(37,75):False,(37,76):False,(37,77):False,(37,78):False,(37,79):False,(37,80):False,(37,81):False,(37,82):False,(37,83):False,(37,84):False,(37,85):True,(37,86):False,(37,87):True,(37,88):False,(37,89):False,(37,90):False,(37,91):False,(37,92):False,(37,93):False,(37,94):False,(37,95):False,(37,96):False,(37,97):False,(37,98):False,(37,99):False,(37,100):False,(37,101):False,(37,102):False,(37,103):False,(37,104):False,(37,105):False,(37,106):False,

    # Z=38  Strontium
    (38,73):False,(38,74):False,(38,75):False,(38,76):False,(38,77):False,(38,78):False,(38,79):False,(38,80):False,(38,81):False,(38,82):False,(38,83):False,(38,84):True,(38,85):False,(38,86):True,(38,87):True,(38,88):True,(38,89):False,(38,90):False,(38,91):False,(38,92):False,(38,93):False,(38,94):False,(38,95):False,(38,96):False,(38,97):False,(38,98):False,(38,99):False,(38,100):False,(38,101):False,(38,102):False,(38,103):False,(38,104):False,(38,105):False,(38,106):False,(38,107):False,(38,108):False,

    # Z=39  Yttrium
    (39,50):False,(39,51):False,(39,52):False,(39,53):False,(39,54):False,(39,55):False,(39,56):False,(39,57):False,(39,58):False,(39,59):False,(39,60):False,(39,61):False,(39,62):False,(39,63):False,(39,64):False,(39,65):False,(39,66):False,(39,67):False,(39,68):False,(39,69):False,(39,70):False,(39,71):False,(39,72):False,(39,73):False,(39,74):False,(39,75):False,(39,76):False,(39,77):False,(39,78):False,(39,79):False,(39,80):False,(39,81):False,(39,82):False,(39,83):False,(39,84):False,(39,85):False,(39,86):False,(39,87):False,(39,88):False,(39,89):True,(39,90):False,(39,91):False,(39,92):False,(39,93):False,(39,94):False,(39,95):False,(39,96):False,(39,97):False,(39,98):False,(39,99):False,(39,100):False,(39,101):False,(39,102):False,(39,103):False,(39,104):False,(39,105):False,(39,106):False,(39,107):False,(39,108):False,(39,109):False,(39,110):False,(39,111):False,

    # Z=40  Zirconium
    (40,90):True,(40,91):True,(40,92):True,(40,93):False,(40,94):True,(40,95):False,(40,96):True,
    # (others all False — fill remaining from KNOWN_NEUTRONS)

    # Z=41  Niobium
    (41,93):True,

    # Z=42  Molybdenum
    (42,92):True,(42,94):True,(42,95):True,(42,96):True,(42,97):True,(42,98):True,(42,100):True,

    # Z=43  Technetium — no stable isotopes

    # Z=44  Ruthenium
    (44,96):True,(44,98):True,(44,99):True,(44,100):True,(44,101):True,(44,102):True,(44,104):True,

    # Z=45  Rhodium
    (45,103):True,

    # Z=46  Palladium
    (46,102):True,(46,104):True,(46,105):True,(46,106):True,(46,108):True,(46,110):True,

    # Z=47  Silver
    (47,107):True,(47,109):True,

    # Z=48  Cadmium
    (48,106):True,(48,108):True,(48,110):True,(48,111):True,(48,112):True,(48,113):True,(48,114):True,(48,116):True,

    # Z=49  Indium
    (49,113):True,(49,115):True,

    # Z=50  Tin
    (50,112):True,(50,114):True,(50,115):True,(50,116):True,(50,117):True,(50,118):True,(50,119):True,(50,120):True,(50,122):True,(50,124):True,

    # Z=51  Antimony
    (51,121):True,(51,123):True,

    # Z=52  Tellurium
    (52,120):True,(52,122):True,(52,123):True,(52,124):True,(52,125):True,(52,126):True,(52,128):True,(52,130):True,

    # Z=53  Iodine
    (53,127):True,

    # Z=54  Xenon
    (54,124):True,(54,126):True,(54,128):True,(54,129):True,(54,130):True,(54,131):True,(54,132):True,(54,134):True,(54,136):True,

    # Z=55  Caesium
    (55,133):True,

    # Z=56  Barium
    (56,130):True,(56,132):True,(56,134):True,(56,135):True,(56,136):True,(56,137):True,(56,138):True,

    # Z=57  Lanthanum
    (57,138):True,(57,139):True,

    # Z=58  Cerium
    (58,136):True,(58,138):True,(58,140):True,(58,142):True,

    # Z=59  Praseodymium
    (59,141):True,

    # Z=60  Neodymium
    (60,142):True,(60,143):True,(60,144):True,(60,145):True,(60,146):True,(60,148):True,(60,150):True,

    # Z=61  Promethium — no stable isotopes

    # Z=62  Samarium
    (62,144):True,(62,149):True,(62,150):True,(62,152):True,(62,154):True,

    # Z=63  Europium
    (63,151):True,(63,153):True,

    # Z=64  Gadolinium
    (64,154):True,(64,155):True,(64,156):True,(64,157):True,(64,158):True,(64,160):True,

    # Z=65  Terbium
    (65,159):True,

    # Z=66  Dysprosium
    (66,156):True,(66,158):True,(66,160):True,(66,161):True,(66,162):True,(66,163):True,(66,164):True,

    # Z=67  Holmium
    (67,165):True,

    # Z=68  Erbium
    (68,162):True,(68,164):True,(68,166):True,(68,167):True,(68,168):True,(68,170):True,

    # Z=69  Thulium
    (69,169):True,

    # Z=70  Ytterbium
    (70,168):True,(70,170):True,(70,171):True,(70,172):True,(70,173):True,(70,174):True,(70,176):True,

    # Z=71  Lutetium
    (71,175):True,(71,176):True,

    # Z=72  Hafnium
    (72,174):True,(72,176):True,(72,177):True,(72,178):True,(72,179):True,(72,180):True,

    # Z=73  Tantalum
    (73,180):True,(73,181):True,

    # Z=74  Tungsten
    (74,180):True,(74,182):True,(74,183):True,(74,184):True,(74,186):True,

    # Z=75  Rhenium
    (75,185):True,(75,187):True,

    # Z=76  Osmium
    (76,184):True,(76,186):True,(76,187):True,(76,188):True,(76,189):True,(76,190):True,(76,192):True,

    # Z=77  Iridium
    (77,191):True,(77,193):True,

    # Z=78  Platinum
    (78,190):True,(78,192):True,(78,194):True,(78,195):True,(78,196):True,(78,198):True,

    # Z=79  Gold
    (79,197):True,

    # Z=80  Mercury
    (80,196):True,(80,198):True,(80,199):True,(80,200):True,(80,201):True,(80,202):True,(80,204):True,

    # Z=81  Thallium
    (81,203):True,(81,205):True,

    # Z=82  Lead
    (82,204):True,(82,206):True,(82,207):True,(82,208):True,

    # Z=83+ — all radioactive (no stable isotopes)
}

# ── Fill in False for all (Z, A) pairs in KNOWN_NEUTRONS not already in ISOTOPE_DATA ──
# Run this once at import time so every nuclide has an entry.


for _Z, _ns in KNOWN_NEUTRONS.items():# noqa: E402  (adjust import if needed)

    for _N in _ns:
        _key = (_Z, _Z + _N)
        if _key not in ISOTOPE_DATA:
            ISOTOPE_DATA[_key] = {"stable": False}

# Convert bare booleans to dicts (for entries written above as plain True/False)
ISOTOPE_DATA = {
    k: ({"stable": v} if isinstance(v, bool) else v)
    for k, v in ISOTOPE_DATA.items()
}
